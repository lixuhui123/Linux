#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>

int main()
{
    uint64_t i = 0;
    while(1){
        //printf("hello bite~\n");
        i++;
    }
    return 0;
}
