/*=============================================================== 
*   Copyright (C) . All rights reserved.")
*   文件名称： 
*   创 建 者：zhang
*   创建日期：
*   描    述：
================================================================*/
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include "tcpsocket.hpp"

int main(int argc, char *argv[])
{
    if (argc != 3) {
        printf("em: ./tcp_srv host_ip host_port\n");
        return -1;
    }
    std::string ip = argv[1];
    uint16_t port = atoi(argv[2]);

    TcpSocket lst_sock;
    CHECK_RET(lst_sock.Socket()); //创建套接字
    CHECK_RET(lst_sock.Bind(ip, port));//绑定地址信息
    CHECK_RET(lst_sock.Listen());//开始监听
    while(1) {
        TcpSocket newsock;
        bool ret = lst_sock.Accept(&newsock);//获取新连接
        if (ret == false) {
            continue;
        }
        std::string buf;
        newsock.Recv(&buf);
        std::cout << "http req:[" << buf << "]\n";

        std::string body = "<html><body><h1>Hello World</h1></body></html>";
        std::string blank = "\r\n";
        std::stringstream header;
        header << "Content-Length: " << body.size() << "\r\n";
        header << "Content-Type: text/html\r\n";
        header << "Location: http://www.baidu.com/\r\n";//将请求重定向到百度
        std::string first = "HTTP/1.1 302 Found\r\n";

        newsock.Send(first);//发送首行信息
        newsock.Send(header.str());//发送头部信息
        newsock.Send(blank);//发送空行
        newsock.Send(body);//发送正文
        newsock.Close();
    }
    lst_sock.Close();
    return 0;
}

