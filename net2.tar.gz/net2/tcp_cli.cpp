/*=============================================================== 
*   Copyright (C) . All rights reserved.")
*   文件名称： 
*   创 建 者：zhang
*   创建日期：
*   描    述：通过封装的tcpsocket类实现一个tcp客户端程序
*       1. 创建套接字
*       2. 绑定地址信息（不推荐）
*       3. 向服务端发起连接请求
*       while(1) {
*           4. 先发送数据
*           5. 接收数据
*       } 
*       6. 关闭套接字
================================================================*/
#include <iostream>
#include <stdlib.h>
#include <signal.h>
#include "tcpsocket.hpp"


void sigcb(int signo)
{
    printf("连接断开收到SIGPIPE信号\n");
}
int main(int argc, char *argv[])
{
    if (argc != 3) {
        printf("em: ./tcp_cli srv_ip srv_port\n");
        return -1;
    }
    signal(SIGPIPE, sigcb);
    std::string ip = argv[1];
    uint16_t port = atoi(argv[2]);

    TcpSocket cli_sock;
    CHECK_RET(cli_sock.Socket());//创建套接字
    CHECK_RET(cli_sock.Connect(ip, port));//向服务端发起连接
    while(1) {
        cal_t tmp;//定义一个变量就会拥有一块空间
        tmp.num1 = 10; //成员变量的赋值，就是给这个空间的指定位置指定大小的空间赋值
        tmp.num2 = 20; //这就是数据对象，在内存中对二进制数据进行组织过程-序列化
        tmp.op = '+';  //哪个数据对象在什么位置如何组织就是协议
        int fd = cli_sock.GetFd();

        send(fd, (void*)&tmp, sizeof(cal_t), 0);//二进制数据传输
        sleep(100);
    }
    cli_sock.Close();
    return 0;
}
